SONIKA JEWELLERS ISLAMABAD — WEBSITE PACKAGE

Files:
- index.html
- styles.css
- script.js

Edit business content in index.html.
Edit colors, spacing and typography in styles.css.
Edit interactions in script.js.

Notes:
- Gallery/hero use externally hosted Unsplash images for visual presentation only; they are not claimed to be store inventory.
- Google Maps embed uses the listing coordinates.
- WhatsApp links use the phone number shown on the current Google Maps listing.
- Sunday is displayed as Closed because no Sunday opening interval was returned by the listing data.
